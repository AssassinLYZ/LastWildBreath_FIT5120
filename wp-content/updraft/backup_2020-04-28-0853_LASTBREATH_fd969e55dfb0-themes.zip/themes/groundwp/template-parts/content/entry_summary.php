<?php
/**
 * Template part for displaying a post's summary
 *
 * @package groundwp
 */

namespace GroundWP\GroundWP;

?>

<div class="entry-summary">
	<?php the_excerpt(); ?>
</div><!-- .entry-summary -->
