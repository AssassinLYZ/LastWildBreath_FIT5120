-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/04/19 on 08:24
--
-- Database : bitnami_wordpress
--
-- Backup   Table  : wp_usermeta
-- Snapshot Table  : 1587327863_usermeta
--
-- SQL    : SELECT * FROM wp_usermeta LIMIT 0,10000
-- Offset : 0
-- Rows   : 33
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1587327863_usermeta`
--
DROP TABLE  IF EXISTS `1587327863_usermeta`;
CREATE TABLE `1587327863_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wp_usermeta`
-- Number of rows: 33
--
INSERT INTO `1587327863_usermeta` VALUES 
(1,1,'nickname','user'),
 (2,1,'first_name',''),
 (3,1,'last_name',''),
 (4,1,'description',''),
 (5,1,'rich_editing','true'),
 (6,1,'syntax_highlighting','true'),
 (7,1,'comment_shortcuts','false'),
 (8,1,'admin_color','fresh'),
 (9,1,'use_ssl','0'),
 (10,1,'show_admin_bar_front','true'),
 (11,1,'locale',''),
 (12,1,'wp_capabilities','a:1:{s:13:\"administrator\";b:1;}'),
 (13,1,'wp_user_level','10'),
 (14,1,'dismissed_wp_pointers','theme_editor_notice,plugin_editor_notice,tp09_edit_drag_drop_sort'),
 (15,1,'show_welcome_panel','1'),
 (16,1,'session_tokens','a:6:{s:64:\"37dc6cec2453f58e00a442253e5d8bd6ff225c9bae2589db3cfe05dae7f8110f\";a:4:{s:10:\"expiration\";i:1587611092;s:2:\"ip\";s:11:\"58.96.69.69\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36\";s:5:\"login\";i:1586401492;}s:64:\"70db24dd594e2720abeaccbf39bf177684416393ac715ee163072f2a903c5543\";a:4:{s:10:\"expiration\";i:1587625051;s:2:\"ip\";s:11:\"58.96.69.69\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36\";s:5:\"login\";i:1586415451;}s:64:\"cc020e515ba5d2e9b51db371dfcc6076f0e7c826449ac5c3ceaf03fd07c85601\";a:4:{s:10:\"expiration\";i:1587644108;s:2:\"ip\";s:11:\"58.96.69.69\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36\";s:5:\"login\";i:1586434508;}s:64:\"a2c0483d64a09e954f32c3fe86b91ee14ad76f051b17def441fb8c8bd3f20278\";a:4:{s:10:\"expiration\";i:1587644112;s:2:\"ip\";s:11:\"58.96.69.69\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36\";s:5:\"login\";i:1586434512;}s:64:\"ccddde3da5ac7a579e010dd56e0e49599cfb6710a05c3089d5e29742902dbf03\";a:4:{s:10:\"expiration\";i:1588108151;s:2:\"ip\";s:11:\"58.96.69.69\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Safari/537.36\";s:5:\"login\";i:1586898551;}s:64:\"f1369bacabbcec46f8222c564bc68bae2a2babedb87f9c49f584497857149645\";a:4:{s:10:\"expiration\";i:1587497811;s:2:\"ip\";s:11:\"58.96.69.69\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36\";s:5:\"login\";i:1587325011;}}'),
 (17,1,'wp_user-settings','mfold=o&libraryContent=browse&editor=tinymce'),
 (18,1,'wp_user-settings-time','1587322052'),
 (19,1,'jetpack_tracks_anon_id','jetpack:PRxklIhNM9DsMmf8VNrze5MB'),
 (20,1,'wp_elementor_connect_common_data','a:7:{s:9:\"client_id\";s:32:\"XCdDbX07uEu3H9QsvIo7RSb1BLy2pi8X\";s:11:\"auth_secret\";s:32:\"EeiVHpVN56STMXghc0O9qqliS2ElPUz4\";s:12:\"access_token\";s:32:\"45gekEBnSxiXvO0yoo4GIuuTd48zacXg\";s:19:\"access_token_secret\";s:32:\"0piq0kMOQp44T4d01xx7XQX4IvmsxRv5\";s:10:\"token_type\";s:6:\"bearer\";s:4:\"user\";O:8:\"stdClass\":1:{s:5:\"email\";s:23:\"goatherd.eric@gmail.com\";}s:19:\"data_share_opted_in\";b:1;}'),
 (21,1,'wp_dashboard_quick_press_last_post_id','7'),
 (22,1,'community-events-location','a:1:{s:2:\"ip\";s:10:\"58.96.69.0\";}'),
 (23,1,'managenav-menuscolumnshidden','a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
 (24,1,'metaboxhidden_nav-menus','a:2:{i:0;s:12:\"add-post_tag\";i:1;s:15:\"add-post_format\";}'),
 (25,1,'elementor_introduction','a:2:{s:19:\"colorPickerDropping\";b:1;s:10:\"rightClick\";b:1;}'),
 (26,1,'nav_menu_recently_edited','2'),
 (27,1,'wp_tablepress_user_options','{\"user_options_db_version\":40,\"admin_menu_parent_page\":\"middle\",\"message_first_visit\":true}'),
 (28,1,'managetablepress_listcolumnshidden','a:1:{i:0;s:22:\"table_last_modified_by\";}'),
 (29,1,'closedpostboxes_tablepress_add','a:1:{i:0;s:24:\"tablepress_add-add-table\";}'),
 (30,1,'metaboxhidden_tablepress_add','a:0:{}'),
 (31,1,'closedpostboxes_tablepress_edit','a:0:{}'),
 (32,1,'metaboxhidden_tablepress_edit','a:0:{}'),
 (33,1,'_new_email','a:2:{s:4:\"hash\";s:32:\"198844d99ebb853d3786a24fdf760281\";s:8:\"newemail\";s:23:\"goatherd.eric@gmail.com\";}');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
