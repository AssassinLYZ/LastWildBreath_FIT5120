-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/04/19 on 08:25
--
-- Database : bitnami_wordpress
--
-- Backup   Table  : wp_mb_relationships
-- Snapshot Table  : 1587327863_mb_relationships
--
-- SQL    : SELECT * FROM wp_mb_relationships LIMIT 0,10000
-- Offset : 0
-- Rows   : 0
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1587327863_mb_relationships`
--
DROP TABLE  IF EXISTS `1587327863_mb_relationships`;
CREATE TABLE `1587327863_mb_relationships` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `from` bigint(20) unsigned NOT NULL,
  `to` bigint(20) unsigned NOT NULL,
  `type` varchar(44) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `order_from` bigint(20) unsigned NOT NULL,
  `order_to` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `from` (`from`),
  KEY `to` (`to`),
  KEY `type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wp_mb_relationships`
-- Number of rows: 0
--
--
-- Data for table `wp_mb_relationships`
-- Number of rows: 0
--
SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
