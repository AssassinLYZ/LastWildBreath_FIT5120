-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/04/19 on 08:24
--
-- Database : bitnami_wordpress
--
-- Backup   Table  : wp_term_relationships
-- Snapshot Table  : 1587327863_term_relationships
--
-- SQL    : SELECT * FROM wp_term_relationships LIMIT 0,10000
-- Offset : 0
-- Rows   : 24
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1587327863_term_relationships`
--
DROP TABLE  IF EXISTS `1587327863_term_relationships`;
CREATE TABLE `1587327863_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wp_term_relationships`
-- Number of rows: 24
--
INSERT INTO `1587327863_term_relationships` VALUES 
(26,3,0),
 (27,3,0),
 (28,3,0),
 (29,3,0),
 (30,3,0),
 (31,3,0),
 (131,2,0),
 (132,2,0),
 (133,2,0),
 (134,2,0),
 (135,2,0),
 (136,2,0),
 (237,4,0),
 (240,4,0),
 (244,4,0),
 (248,4,0),
 (250,4,0),
 (256,4,0),
 (259,4,0),
 (261,4,0),
 (280,4,0),
 (478,1,0),
 (478,5,0),
 (478,7,0);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
