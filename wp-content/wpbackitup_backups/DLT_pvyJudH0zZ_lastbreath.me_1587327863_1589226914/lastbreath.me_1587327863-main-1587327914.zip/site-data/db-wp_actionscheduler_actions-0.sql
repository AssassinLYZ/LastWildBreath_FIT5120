-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/04/19 on 08:24
--
-- Database : bitnami_wordpress
--
-- Backup   Table  : wp_actionscheduler_actions
-- Snapshot Table  : 1587327863_actionscheduler_actions
--
-- SQL    : SELECT * FROM wp_actionscheduler_actions LIMIT 0,10000
-- Offset : 0
-- Rows   : 4
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1587327863_actionscheduler_actions`
--
DROP TABLE  IF EXISTS `1587327863_actionscheduler_actions`;
CREATE TABLE `1587327863_actionscheduler_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `scheduled_date_gmt` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  `scheduled_date_local` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  `args` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schedule` longtext COLLATE utf8mb4_unicode_520_ci,
  `group_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `attempts` int(11) NOT NULL DEFAULT '0',
  `last_attempt_gmt` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  `last_attempt_local` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  `claim_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `extended_args` varchar(8000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `hook` (`hook`),
  KEY `status` (`status`),
  KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  KEY `args` (`args`),
  KEY `group_id` (`group_id`),
  KEY `last_attempt_gmt` (`last_attempt_gmt`),
  KEY `claim_id` (`claim_id`)
) ENGINE=InnoDB AUTO_INCREMENT=480 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wp_actionscheduler_actions`
-- Number of rows: 4
--
INSERT INTO `1587327863_actionscheduler_actions` VALUES 
(476,'action_scheduler/migration_hook','complete','2020-04-19 12:07:16','2020-04-19 12:07:16','[]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1587298036;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1587298036;}',1,1,'2020-04-19 12:07:16','2020-04-19 12:07:16',0,NULL),
 (477,'wpforms_process_entry_emails_meta_cleanup','pending','2020-04-20 00:00:00','2020-04-20 00:00:00','{\"tasks_meta_id\":1}','O:32:\"ActionScheduler_IntervalSchedule\":5:{s:22:\"\0*\0scheduled_timestamp\";i:1587340800;s:18:\"\0*\0first_timestamp\";i:1587340800;s:13:\"\0*\0recurrence\";i:86400;s:49:\"\0ActionScheduler_IntervalSchedule\0start_timestamp\";i:1587340800;s:53:\"\0ActionScheduler_IntervalSchedule\0interval_in_seconds\";i:86400;}',2,0,'1970-01-02 00:00:01','1970-01-02 00:00:01',0,NULL),
 (478,'action_scheduler/migration_hook','complete','2020-04-19 15:14:24','2020-04-19 15:14:24','[]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1587309264;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1587309264;}',1,1,'2020-04-19 15:15:07','2020-04-19 15:15:07',0,NULL),
 (479,'action_scheduler/migration_hook','complete','2020-04-19 15:15:07','2020-04-19 15:15:07','[]','O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1587309307;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1587309307;}',1,1,'2020-04-19 15:15:18','2020-04-19 15:15:18',0,NULL);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
