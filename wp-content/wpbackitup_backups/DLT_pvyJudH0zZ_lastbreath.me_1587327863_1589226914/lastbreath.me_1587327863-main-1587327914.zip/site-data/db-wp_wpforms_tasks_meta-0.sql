-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/04/19 on 08:24
--
-- Database : bitnami_wordpress
--
-- Backup   Table  : wp_wpforms_tasks_meta
-- Snapshot Table  : 1587327863_wpforms_tasks_meta
--
-- SQL    : SELECT * FROM wp_wpforms_tasks_meta LIMIT 0,10000
-- Offset : 0
-- Rows   : 1
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1587327863_wpforms_tasks_meta`
--
DROP TABLE  IF EXISTS `1587327863_wpforms_tasks_meta`;
CREATE TABLE `1587327863_wpforms_tasks_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wp_wpforms_tasks_meta`
-- Number of rows: 1
--
INSERT INTO `1587327863_wpforms_tasks_meta` VALUES 
(1,'wpforms_process_entry_emails_meta_cleanup','Wzg2NDAwXQ==','2020-04-19 12:07:21');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
