-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/04/19 on 08:25
--
-- Database : bitnami_wordpress
--
-- Backup   Table  : wp_wpdatacharts
-- Snapshot Table  : 1587327863_wpdatacharts
--
-- SQL    : SELECT * FROM wp_wpdatacharts LIMIT 0,10000
-- Offset : 0
-- Rows   : 0
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1587327863_wpdatacharts`
--
DROP TABLE  IF EXISTS `1587327863_wpdatacharts`;
CREATE TABLE `1587327863_wpdatacharts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wpdatatable_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `engine` enum('google','highcharts','chartjs') NOT NULL,
  `type` varchar(255) NOT NULL,
  `json_render_data` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Data for table `wp_wpdatacharts`
-- Number of rows: 0
--
--
-- Data for table `wp_wpdatacharts`
-- Number of rows: 0
--
SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
