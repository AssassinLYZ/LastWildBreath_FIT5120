-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2020/04/19 on 08:24
--
-- Database : bitnami_wordpress
--
-- Backup   Table  : wp_actionscheduler_logs
-- Snapshot Table  : 1587327863_actionscheduler_logs
--
-- SQL    : SELECT * FROM wp_actionscheduler_logs LIMIT 0,10000
-- Offset : 0
-- Rows   : 10
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1587327863_actionscheduler_logs`
--
DROP TABLE  IF EXISTS `1587327863_actionscheduler_logs`;
CREATE TABLE `1587327863_actionscheduler_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action_id` bigint(20) unsigned NOT NULL,
  `message` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `log_date_gmt` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  `log_date_local` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  PRIMARY KEY (`log_id`),
  KEY `action_id` (`action_id`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `wp_actionscheduler_logs`
-- Number of rows: 10
--
INSERT INTO `1587327863_actionscheduler_logs` VALUES 
(1,476,'action created','2020-04-19 12:07:16','2020-04-19 12:07:16'),
 (2,476,'action started via Async Request','2020-04-19 12:07:16','2020-04-19 12:07:16'),
 (3,476,'action complete via Async Request','2020-04-19 12:07:16','2020-04-19 12:07:16'),
 (4,477,'action created','2020-04-19 12:07:21','2020-04-19 12:07:21'),
 (5,478,'action created','2020-04-19 15:14:24','2020-04-19 15:14:24'),
 (6,478,'action started via WP Cron','2020-04-19 15:15:07','2020-04-19 15:15:07'),
 (7,478,'action complete via WP Cron','2020-04-19 15:15:07','2020-04-19 15:15:07'),
 (8,479,'action created','2020-04-19 15:15:07','2020-04-19 15:15:07'),
 (9,479,'action started via WP Cron','2020-04-19 15:15:18','2020-04-19 15:15:18'),
 (10,479,'action complete via WP Cron','2020-04-19 15:15:18','2020-04-19 15:15:18');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
